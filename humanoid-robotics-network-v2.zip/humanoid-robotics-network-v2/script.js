const observer = new IntersectionObserver((entries)=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting){ entry.target.classList.add('is-visible'); }
  });
},{threshold:.12});
document.querySelectorAll('.section, .image-strip, .gallery').forEach(el=>{
  el.classList.add('reveal'); observer.observe(el);
});
