# Humanoid Robotics Network website v2

Static GitHub Pages website.

## Upload to GitHub

Upload all files in this folder to the root of the `website` repository:

- `index.html`
- `style.css`
- `script.js`
- all `.jpg` images
- `README.md`

This version intentionally keeps all image files in the repository root, so GitHub web upload is easier.

## Publish

Repository Settings → Pages → Deploy from a branch → `main` → `/ (root)`.
